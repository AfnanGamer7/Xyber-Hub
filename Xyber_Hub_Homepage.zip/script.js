document.addEventListener("DOMContentLoaded", function() {
    console.log("Xyber Hub Loaded");
});
